print("Welcome to Python Pizza Delivary!")
size= input( "What size pizza do you want? S, M, or L ")
add_pepperoni = input("Do you want pepperoni? Y or N ")
extra_cheese = input("Do you want extra cheese? Y or N ")
if size=="S":
  total= 15
elif size=="M":
  total= 20
elif size=="L":
  total= 25
if add_pepperoni=="Y":
  total= total+ 2
elif add_pepperoni== "N":
  total= total+ 0
if extra_cheese=="Y":
  total= total+ 1
elif extra_cheese== "N":
  total= total+ 0
print(f"Your final bill is: ${total}")
print("Thank you for using Pizza Delivary app")
