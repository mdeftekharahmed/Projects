print("Welcome to the love calculator! \n")
name1=input("What is your name? \n")
name2=input("What is her/his name? \n")
#  Don't change the code above
combined_string= name1 + name2 
lower_case_string= combined_string.lower()
t=lower_case_string.count("t")
r=lower_case_string.count("r")
u=lower_case_string.count("u")
e=lower_case_string.count("e")

true= t+r+u+e

l=lower_case_string.count("l")
o=lower_case_string.count("o")
v=lower_case_string.count("v")
e=lower_case_string.count("e")

love= l+o+v+e

str_love_score=str(true)+ str(love)
love_score = int(str_love_score)

if (love_score < 10) or (love_score > 85):
  print(f"Your score is {love_score}, you go together like coke and mentos.")
elif (love_score >= 40) and (love_score <= 50):
  print(f"Your score is {love_score}, you are alright together.")
else:
  print(f"Your score is {love_score}.")
  
